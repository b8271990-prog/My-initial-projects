# 📊 Анализ оценок

Программа строит график оценок за четверти и вычисляет среднее значение.

## Технологии
- Python 3
- matplotlib

## Запуск
pip install matplotlib
python main.py


# 📊 Grade Analysis

The program plots the grades for the quarters and calculates the average.

## Technologies
- Python 3
- matplotlib

## Running
pip install matplotlib
python main.py